package autotaxis.bolivar.information.autotaxis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
